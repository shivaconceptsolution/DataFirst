﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataFirst.Models;
using System.Data;
namespace DataFirst.Controllers
{
    public class EmpcodeController : Controller
    {
        //
        // GET: /Empcode/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
            var data = db.Employees.ToList();
            return View(data);
        }

        public ActionResult AddEmp()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddEmp(Employee obj)
        {
            db.Employees.Add(obj);
            db.SaveChanges();
            return View();
        }

        public ActionResult UpdateEmp(string id)
        {
            var s = db.Employees.Find(id);
            return View(s);
        }
        [HttpPost]
        public ActionResult UpdateEmp(Employee obj)
        {
            db.Entry(obj).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult DeleteEmp(string id)
        {
            var s = db.Employees.Find(id);
            db.Employees.Remove(s);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
