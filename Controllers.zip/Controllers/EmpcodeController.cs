﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataFirst.Models;
namespace DataFirst.Controllers
{
    public class EmpcodeController : Controller
    {
        //
        // GET: /Empcode/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
            var data = db.Employees.ToList();
            return View(data);
        }

        public ActionResult AddEmp()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddEmp(Employee obj)
        {
            db.Employees.Add(obj);
            db.SaveChanges();
            return View();
        }
    }
}
